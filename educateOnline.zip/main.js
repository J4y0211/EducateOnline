const registerForm = document.getElementById('register-form');
const searchForm = document.getElementById('search-form');
const searchResults = document.getElementById('search-results');
const registeredUsers = document.getElementById('registered-users');

let users = [];

registerForm.addEventListener('submit', (event) => {
  event.preventDefault();
  
  const id = document.getElementById('id').value;
  const name = document.getElementById('name').value;
  const email = document.getElementById('email').value;
  const phone = document.getElementById('phone').value;
  const photo = document.getElementById('photo').files[0];
  
  const user = { id, name, email, phone, photo };
  users.push(user);
  
  registeredUsers.innerHTML = '';
  users.forEach((user) => {
    const userCard = document.createElement('div');
    userCard.classList.add('user-card');
    
    const userId = document.createElement('p');
    userId.innerText = `ID: ${user.id}`;
    userCard.appendChild(userId);
    
    const userName = document.createElement('p');
    userName.innerText = `Nombre: ${user.name}`;
    userCard.appendChild(userName);
    
    const userEmail = document.createElement('p');
    userEmail.innerText = `Email: ${user.email}`;
    userCard.appendChild(userEmail);
    
    const userPhone = document.createElement('p');
    userPhone.innerText = `Teléfono: ${user.phone}`;
    userCard.appendChild(userPhone);
    
    const userPhoto = document.createElement('img');
    userPhoto.src = URL.createObjectURL(user.photo);
    userPhoto.classList.add('user-photo');
    userCard.appendChild(userPhoto);
    
    registeredUsers.appendChild(userCard);
  });
  
  document.getElementById('register-form').reset();
});

searchForm.addEventListener('input', (event) => {
  event.preventDefault();

  const searchId = document.getElementById('search-id').value;

  const filteredUsers = users.filter((user) => {
    return user.id.startsWith(searchId);
  });

  registeredUsers.innerHTML = '';

  if (filteredUsers.length > 0) {
    filteredUsers.forEach((user) => {
      const userCard = document.createElement('div');
      userCard.classList.add('user-card');
      
      const userId = document.createElement('p');
      userId.innerText = `ID: ${user.id}`;
      userCard.appendChild(userId);
      
      const userName = document.createElement('p');
      userName.innerText = `Nombre: ${user.name}`;
      userCard.appendChild(userName);
      
      const userEmail = document.createElement('p');
      userEmail.innerText = `Email: ${user.email}`;
      userCard.appendChild(userEmail);
      
      const userPhone = document.createElement('p');
      userPhone.innerText = `Teléfono: ${user.phone}`;
      userCard.appendChild(userPhone);
      
      const userPhoto = document.createElement('img');
      userPhoto.src = URL.createObjectURL(user.photo);
      userPhoto.classList.add('user-photo');
      userCard.appendChild(userPhoto);
      
      registeredUsers.appendChild(userCard);
    });
  } else {
    const noResultsMessage = document.createElement('p');
    noResultsMessage.innerText = 'No se encontraron resultados.';
    registeredUsers.appendChild(noResultsMessage);
  }

});
